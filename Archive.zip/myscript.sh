#!/bin/bash

counter=100
while [ $counter -ge 1 ]
do
	echo HELLO
	((counter--))
	sleep 0.1
done

