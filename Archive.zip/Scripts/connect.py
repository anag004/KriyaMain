# This script runs on the user and connects to the central server
# Takes input as the ipaddress of central server which will be fixed

import socket
import sys
import subprocess

serverip = sys.argv[1]

# The port which the server is listening on
serverport = 6000

# Socket to ping the server
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.connect((serverip, serverport))

msg = sock.recv(1024)

sock.close()

# Get the value of port
connectport = msg.split(" ")[-1]

print(connectport)

# Make another socket to connect to server
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.connect((serverip, int(connectport)))

print(sock.recv(2**15))

while(true):
	sock.send(raw_input())
	print(sock.recv(2**15))