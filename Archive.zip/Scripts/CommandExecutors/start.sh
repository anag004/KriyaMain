#!/bin/bash

# This command starts the virtual machine takes input vmName, hostIP, userIP

ssh disa@$2 virsh start $vmName_$3
