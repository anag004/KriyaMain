# This script destroys the VM on the remote guest

ssh disa_server@$2 '
virsh undefine $vmName_$3 --remove-all-storage
sudo rm /home/disa_server/kvm-pool/$vmName_$3/$vmName_$3.qcow2
sudo rmdir /home/disa_server/kvm-pool/$vmName_$3
'