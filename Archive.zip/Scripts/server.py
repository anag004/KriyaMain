#This script assigns ports to incoming requests for communication. Ports are assigned from 6001 
# through 6050 allowing a maximum of 50 connections

import socket
import subprocess

# The ports array stores the objects which call the subprocesses
ports = [None]*50
reqips = [None]*50

# Main port is the port to which all computers requesting virtual machines connect
mainport = 6000

# Frees ports which no longer need to be used
def free():
	for i in range(50):
		if ports[i] != None:
			if ports[i].poll() != None:
				ports[i] = None
				reqips[i] = None

# The getport finds a free port and assigns it a process
def getport(ipaddr):
	for i in range(50):
		if ports[i] == None:
			useport = mainport+i+1
			ports[i] = subprocess.Popen(['python', 'comm.py', str(useport), str(ipaddr)])
			reqips[i] = ipaddr
			return useport

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
print "Socket successfully created"

# This command initiates the listening on mainport
s.bind(('', mainport))
s.listen(20)
print "Socket is listening"

while True:
	# .accept() halts the script until a connection is made
	c, addr = s.accept() 
	print "Got connection from ", 
	# The free command frees any ports that have completed their scripts
	free()
	if addr[0] in reqips:
		c.send("You have already requested a port. Multiple ports are not allowed.")
	else:
		# Assign the port
		c.send(str(getport(addr[0])))
	c.close()
 	

