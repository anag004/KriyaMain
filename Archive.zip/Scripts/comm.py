# This script is called from the server.py script and communicates with clients who wish to create
# virtual machines. This gets a command line argument which is the port number and a list of ports 
# imported from the server.py script
# This script runs on the server

# create <name> <ramsize in MB> <hard disk size in GB>G --> Create virtual machine with a given name ramsize in MB and a hard disk space in GB
# start --> This command starts the virtual machine
# connect --> This command opens an ssh terminal to the virtual machine
# shutdown --> Graceful shutdown of the VM
# suspend --> Suspends the VM
# fshut --> Powers down the VM forcefully
# close --> shuts down all VMs and exits the session
# listvms --> Lists the VMs
# destroy -> Destroys a VM

# Pending tasks:
# Write command executor scripts

import sys
import socket
import subprocess

print("NEW CONNECTION CREATED")

# This is a list IP addresses of all available hosts on the network  
allIPs = []

# The port on which the current script is listening
port = int(sys.argv[1])
# The ip address of the user requesting controlling the interface 
ipaddr = sys.argv[2]

# 3 arrays which list all the vms the current user owns in the format ["vm-name", "ip add of host machine"]
vmNames = []
vmIPs = [] 
hostIPs = []
vmStates = [] #0 - off, 1 - on, 2 - paused

minRAM = 1024
maxRAM = 6*1024
minDisk = 3
maxDisk = 100

# Socket to listen to the port
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(('', port))
s.listen(1)

def findipaddr():
	for i in allIPs:
		print("IN")
		checkport = 2000
		checksock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		checksock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		checksock.connect((i, checkport))
		print("CONNECTED")
		# As soon as a connection is established a true/false message is returned
		isFreeMsg = checksock.recv(1024)
		if (isFreeMsg == 'true'):
			return i
		checksock.close()
	return False


def isInteger(s):
	try:
		return int(s)
	except ValueError:
		return False

def printFile(filename, c):
	print("Opening help file list")
	fileObj = open(filename, "r")
	fileText = fileObj.read()
	c.sendall(fileText)

def runScript(scriptname, c):
	output = subprocess.check_output(['bash', scriptname])
	c.sendall(output)

# This function gives the help instructions to the user. 
def help(c):
	#Print the list of commands
	printFile("CommandDescriptors/listCommands.txt", c)
	while True:
		ins = str(c.recv(1024))[:-1]
		errmsg = "ERROR: Please type a valid number or command."
		#Print the documentation. 
		if (len(ins) == 1):
			cmdno = int(ins)
			if (cmdno == 1):
				runScript("CommandDescriptors/create.sh", c)
			elif (cmdno == 2):
				runScript("CommandDescriptors/start.sh", c)
			elif (cmdno == 3):
				runScript("CommandDescriptors/connect.sh", c)
			elif (cmdno == 4):
				runScript("CommandDescriptors/shutdown.sh", c)
			elif (cmdno == 5):
				runScript("CommandDescriptors/suspend.sh", c)
			elif (cmdno == 6):
				runScript("CommandDescriptors/resume.sh", c)
			elif (cmdno == 7):
				runScript("CommandDescriptors/close.sh", c)
			elif (cmdno == 8):
				runScript("CommandDescriptors/listvms.sh", c)
			elif (cmdno == 9):
				runScript("CommandDescriptors/destroy.sh", c)
			else:
				c.send(errmsg)
		elif (ins == "exit"):
			return
		else:
			c.send(errmsg)

# Checks to see if the vmName entered is alphanumeric and unique
# If yes, returns True. If not, returns False and prints error message
def checkVmName(vmName, c):
	# First check if all characters are alphanumeric
	if (vmName.isalnum() == False):
		c.send("The VM name should consist of alphanumeric characters only. No spaces or underscores allowed.\n")
		return False

	# Check if the vmName already does not occur in the vm list
	if (vmName in vmNames):
		c.send("You already own a VM called " + vmName + ". Choose a different name.\n")
		return False

	# If we pass both tests return True
	return True

#Checks the number of arguments in a given command
def checkArgNumber(cmdwords, nArgs, c):
	if (nArgs == len(cmdwords)-1):
		return True
	else:
		c.send(cmdwords[0] + " takes " + str(nArgs) + " argument(s). However, you only entered " + str(len(cmdwords)-1) + ".\n")
		return False

#Checks to see if the RAM entry is an integer and within acceptable range
# Prints error message if not
def checkRAM(vmRAM, c):
	vmRAMValue = isInteger(vmRAM)
	# Checks if the RAM value is an integer
	if (vmRAMValue == False):
		c.send("Please enter an integral value for the RAM size.\n")
		return False
	
	#Checks if the RAM value is larger than 1GB
	if (vmRAMValue < minRAM):
		c.send("You have allocated too little RAM. RAM should be atleast " + str(minRAM) + "MB.\n")
		return False

	#Checks if the RAM value is smalle than 6GB
	if (vmRAMValue > maxRAM):
		c.send("You have allocated too much RAM. RAM should be less than " + str(maxRAM) + "MB.\n")
		return False

	return True

def checkVmDisk(vmDisk, c):
	vmDiskValue = isInteger(vmDisk)
	# Checks if disk value is an integer
	if (vmDiskValue == False):
		c.send("Please enter an integral value for the disk size.\n")
		return False

	#Checks if the disk value is larger than minDisk
	if (vmDiskValue < minDisk):
		c.send("You have allocated too little disk space. Allocate atleast " + str(minDisk) + "GB.\n")
		return False

	# Checks if disk value is smaller than maxDisk
	if (vmDiskValue > maxDisk):
		c.send("You have allocated too much disk space. Allocate not more than " + str(maxDisk) + "GB.\n")
		return False

	return True

def create(cmdwords, c):
	print("CREATE REQUEST")
	if (checkArgNumber(cmdwords, 3, c) == True):
		#If the correct no. of args proceed
		vmName = cmdwords[1]
		vmRAM = cmdwords[2]
		vmDisk = cmdwords[3]
		# This code block checks if the name of the VM is correct
		if (checkVmName(vmName, c) == False):
			return

		#This code block checks if the amount of RAM allocated to the VM is correct
		if (checkRAM(vmRAM, c)) == False:
			return

		#This code checks the hard disk space
		if(checkVmDisk(vmDisk, c) == False):
			return

		# Run a script to create the virtual machine
		freeHostIP = findipaddr() #Finds the ip address of a free host
		if (freeHostIP == False):
			c.send("No free host available. Please try again later.")
			return
		# The VM created will be named vmName_ipaddr
		vmNames.append(vmName)
		hostIPs.append(freeHostIP)
		hostIPs.append(0)
		vmStates.append(0)
		# The create script takes three arguments, name of the VM, the ip addres of host, and the ipaddress of user
		vmIPs.append(subprocess.check_output(['bash', '/CommandExecutors/create.sh', vmName, vmRAM, vmDisk, freeHostIP, ipaddr]))
		c.send("Virtual machine " + vmName + " created. To start it run start " + vmName + ". A default user with username ubuntu and password asdf has been created on the machine.\n")
	else:
		return 

def start(cmdwords, c):
	#Check the cmdwords has one arguments
	if (checkArgNumber(cmdwords, 1, c) == True):
		vmName = cmdwords[1]

		# Check if the vmName exists in the vmName array
		if (vmName not in vmNames):
			c.send("The virtual machine named " + vmName + " does not exist.\n")
			return
		
		# Else find the Id of the virtual machine
		vmId = vmNames.index(vmName)

	#Check the state of the virtual machine
	if (vmStates[vmId] == 1):
		c.send(vmName + " is already running.\n")
		return
	if (vmStates[vmId] == 2):
		c.send(vmName + " is paused. Use the command resume " + vmName + " if you wish to start it again.\n")
		return

	#If above conditions are met start the virtual machine 
	#Syntax of start.sh takes in vmName hostIP IPuser
	subprocess.call(['bash', '/CommandExecutor/start.sh', vmName, hostIPs[vmId]], ipaddr)
	vmStates[vmId] = 1
	c.send(vmName + " is running.\n")
	return

def connect(cmdwords, c):
	if (checkArgNumber(cmdwords, 1, c) == True):
		vmName = cmdwords[1]

		# Check if the vmName exists in the vmName array
		if (vmName not in vmNames):
			c.send("The virtual machine named " + vmName + " does not exist.\n")
			return
		
		# Else find the Id of the virtual machine
		vmId = vmNames.index(vmName)
		vmState = vmStates[vmId]
		if (vmState != 1):
			c.send(vmName + " is not running. To connect a VM must be running.\n")
			return

		subprocess.call(['bash', '/CommandExecutor/connect.sh', vmName, hostIPs[vmId]], ipaddr, vmIPs[vmId])
		return 

def shutdown(cmdwords, c):
	if (checkArgNumber(cmdwords, 1, c) == False): 
		return 

	vmName = cmdwords[1]

	# Check if the vmName exists in the vmName array
	if (vmName not in vmNames):
		c.send("The virtual machine named " + vmName + " does not exist.\n")
		return
	
	# Else find the Id of the virtual machine
	vmId = vmNames.index(vmName)
	vmState = vmStates[vmId]

	if (vmState != 1):
		c.send(vmName + " is not powered on. You can only shutdown a VM that is running. If your VM is suspended resume it first.\n")

	subprocess.call(['bash', '/CommandExecutor/shutdown.sh', vmName, hostIPs[vmId]], ipaddr)
	vmStates[vmId] = 0

def suspend(cmdwords, c):
	if (checkArgNumber(cmdwords, 1, c) == False): 
		return 

	vmName = cmdwords[1]

	# Check if the vmName exists in the vmName array
	if (vmName not in vmNames):
		c.send("The virtual machine named " + vmName + " does not exist.\n")
		return
	
	# Else find the Id of the virtual machine
	vmId = vmNames.index(vmName)
	vmState = vmStates[vmId]

	if (vmState != 1):
		c.send(vmName + " is not powered on. You can only suspend a VM that is running.\n")

	subprocess.call(['bash', '/CommandExecutor/suspend.sh', vmName, hostIPs[vmId]], ipaddr)
	vmStates[vmId] = 2 #Set the state to paused
	return

def resume(cmdwords, c):
	if (checkArgNumber(cmdwords, 1, c) == False): 
		return 

	vmName = cmdwords[1]

	# Check if the vmName exists in the vmName array
	if (vmName not in vmNames):
		c.send("The virtual machine named " + vmName + " does not exist.\n")
		return
	
	# Else find the Id of the virtual machine
	vmId = vmNames.index(vmName)
	vmState = vmStates[vmId]

	if (vmState != 2):
		c.send(vmName + " is not suspended. You can only resume a VM that is suspended.\n")

	subprocess.call(['bash', '/CommandExecutor/suspend.sh', vmName, hostIPs[vmId]], ipaddr)
	vmStates[vmId] = 1 #Set the state to running

def destroy(cmdwords, c):
	if (checkArgNumber(cmdwords, 1, c) == False):
		return

	vmName = cmdwords[1]

	# Check if the vmName exists in the vmName array
	if (vmName not in vmNames):
		c.send("The virtual machine named " + vmName + " does not exist.\n")
		return

	# Else find the Id of the virtual machine
	vmId = vmNames.index(vmName)
	vmState = vmStates[vmId]

	if (vmState != 2):
		c.send(vmName + " is not powered off. You can only destroy a VM that is off.\n")

	subprocess.call(['bash', '/CommandExecutor/destroy.sh', vmName, hostIPs[vmId], ipaddr])
	# Remove it from the array
	vmNames.pop(vmId)
	vmIPs.pop(vmId)
	hostIPs.pop(vmId)
	vmStates.pop(vmId)

def close(cmdwords, c):
	if (checkArgNumber(cmdwords, 0, c) == False):
		return

	#Shutdown then destroy all VMs
	while(len(vmStates) > 0):
		if (vmStates[i] != 0):
			if (vmStates[0] == 2):
				resume(["resume", vmNames[i]], c)
			shutdown(["shutdown", vmNames[i]], c)
		destroy(["destroy", vmNames[i]], c)


	# There is no closing script
	return

def listvms(cmdwords, c):
	if (checkArgNumber(cmdwords, 0, c) == False):
		return

	for i in range(len(vmStates)):
		c.send(str(i+1) + ". " + vmNames[i] + " ")
		if (vmStates[i] == 0):
			c.send("off\n")
		elif (vmStates[i] == 1):
			c.send("running\n")
		elif (vmStates[i] == 2):
			c.send("paused\n")

#This is the main loop that the server runs all the time
while True:
	print("IN WHILE")
	c, addr = s.accept()
	if (addr[0] == ipaddr):
		# If it is from the IP you want send a greeting
		printFile("greet.txt", c)
		while True:
			ins = str(c.recv(1024))[:-1]
			cmdwords = ins.split()
			if (len(cmdwords) < 1):
				break
			if (cmdwords[0] == "help"):
				help(c)
			elif (cmdwords[0] == "create"):
				# Each command has a function which checks the arguments and calls a script
				create(cmdwords, c)
			elif (cmdwords[0] == "start"):
				start(cmdwords, c)
			elif (cmdwords[0] == "connect"):
				connect(cmdwords, c)
			elif (cmdwords[0] == "shutdown"):
				shutdown(cmdwords, c)
			elif (cmdwords[0] == "suspend"):
				suspend(cmdwords, c)
			elif (cmdwords[0] == "resume"):
				resume(cmdwords, c)
			elif (cmdwords[0] == "close"):
				close(cmdwords, c)
				sys.exit()
			elif (cmdwords[0] == "listvms"):
				listvms(cmdwords, c)
			elif(cmdwords[0] == "destroy"):
				destroy(cmdwords, c)
			else:
				c.send("ERROR: Command " + cmdwords[0] + " does not exist.\n")
			print("REACHED END")
		c.close()
	else:
		# Only accept connection if it is from the original IP
		c.send("Connection refused: You are connecting to a port not assigned to you\n")
		c.close()


