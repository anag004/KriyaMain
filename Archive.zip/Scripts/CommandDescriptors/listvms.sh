#!/bin/bash

# Stores formatting
bold=$(tput bold)
normal=$(tput sgr0)

echo "${bold}listvms"
echo "${normal}This will display a list of the VMs you own and their current states."
