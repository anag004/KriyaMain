#!/bin/bash

# Stores formatting
bold=$(tput bold)
normal=$(tput sgr0)

echo "${bold}start <vm-name>"
echo "${normal}This will power on a particular VM you own."
