#include <iostream>
using namespace std;
int main()
{ while( 1)
{
    
    long int n, reversedInteger = 0, remaind, originalInteger;
    long int reversedbin=0;
    int value=0;
    cin >> n;

    originalInteger = n;

    // reversed integer is stored in variable 
    while( n!=0 )
    {
        remaind = n%10;
        reversedInteger = reversedInteger*10 + remaind;
        n /= 10;
    }
   n= originalInteger;


    // palindrome if orignalInteger and reversedInteger are equal
    if (originalInteger == reversedInteger)
        { reversedInteger=0;
        while(n>0)
        {
            remaind= n%2;
        reversedbin
         = reversedbin*10 + remaind;
        n /= 2;
        }
        n= reversedbin;
        while( n!=0 )
    {
        remaind = n%10;
        reversedInteger = reversedInteger*10 + remaind;
        n /= 10;
    }
    if( reversedbin==reversedInteger)
        { value =1;}
                }
    cout << value<< endl;
    
}}