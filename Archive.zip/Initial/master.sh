#!/bin/bash
#./sumscript
#./palindrome

echo REACH

while [ 1 -le 10 ] 
do 
	query=$( ./sumscript )

	if [ $query -eq -1 ]
	then
		break
	fi

	queryres=$( ./palindrome $query )
	./sumscript $queryres
done

echo ./sumscript