#include <iostream>

using namespace std;

#define LL long long int
#define N 1000000
#define REP(i, a) for(LL i = 1; i <= a; i++)

int main() {
	LL ans = 0;
	REP(i, N) {
		int test;
		cout << i << endl;
		cin >> test;
		if (test == 1) ans += i;
	}
	cout << -1 << endl;
	cout << ans << endl;
}