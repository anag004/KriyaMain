#!/bin/bash

# echo "Your port number is 6002" | ncat "$1" 6001
echo $1